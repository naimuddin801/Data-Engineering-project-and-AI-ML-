-- ═══════════════════════════════════════════════════════════
-- Sales Forecasting Project – MySQL Schema & Analytical Queries
-- Author  : Naimuddin
-- Purpose : Inventory planning & sales analytics
-- Engine  : MySQL 8.0
-- ═══════════════════════════════════════════════════════════

-- ─────────────────────────────────────────
-- SCHEMA CREATION
-- ─────────────────────────────────────────

CREATE DATABASE IF NOT EXISTS sales_forecasting;
USE sales_forecasting;

-- Products dimension
CREATE TABLE IF NOT EXISTS dim_products (
    product_id      VARCHAR(20)  PRIMARY KEY,
    product_name    VARCHAR(100) NOT NULL,
    category        VARCHAR(50)  NOT NULL,
    unit_cost       DECIMAL(10,2),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Stores dimension
CREATE TABLE IF NOT EXISTS dim_stores (
    store_id        VARCHAR(20)  PRIMARY KEY,
    store_name      VARCHAR(100),
    region          VARCHAR(50),
    city            VARCHAR(50),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Date dimension
CREATE TABLE IF NOT EXISTS dim_date (
    date_key        DATE        PRIMARY KEY,
    year            SMALLINT    NOT NULL,
    quarter         TINYINT     NOT NULL,
    month           TINYINT     NOT NULL,
    week            TINYINT     NOT NULL,
    day_of_week     TINYINT     NOT NULL,
    is_weekend      TINYINT     NOT NULL DEFAULT 0,
    is_holiday      TINYINT     NOT NULL DEFAULT 0,
    season          VARCHAR(10)
);

-- Fact: Daily Sales
CREATE TABLE IF NOT EXISTS fact_sales (
    sale_id         BIGINT      AUTO_INCREMENT PRIMARY KEY,
    date_key        DATE        NOT NULL,
    product_id      VARCHAR(20) NOT NULL,
    store_id        VARCHAR(20) NOT NULL,
    units_sold      INT         NOT NULL DEFAULT 0,
    unit_price      DECIMAL(10,2) NOT NULL,
    revenue         DECIMAL(14,2) NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (date_key)    REFERENCES dim_date(date_key),
    FOREIGN KEY (product_id)  REFERENCES dim_products(product_id),
    FOREIGN KEY (store_id)    REFERENCES dim_stores(store_id),
    INDEX idx_date      (date_key),
    INDEX idx_product   (product_id),
    INDEX idx_store     (store_id),
    INDEX idx_date_prod (date_key, product_id)
);

-- Fact: Inventory Snapshots
CREATE TABLE IF NOT EXISTS fact_inventory (
    snapshot_id             BIGINT      AUTO_INCREMENT PRIMARY KEY,
    snapshot_date           DATE        NOT NULL,
    product_id              VARCHAR(20) NOT NULL,
    store_id                VARCHAR(20) NOT NULL,
    current_stock           INT         NOT NULL DEFAULT 0,
    safety_stock            INT         NOT NULL DEFAULT 0,
    reorder_point           INT         NOT NULL DEFAULT 0,
    max_stock               INT         NOT NULL DEFAULT 0,
    lead_time_days          TINYINT     NOT NULL DEFAULT 7,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES dim_products(product_id),
    FOREIGN KEY (store_id)   REFERENCES dim_stores(store_id),
    INDEX idx_snapshot_date (snapshot_date)
);

-- Fact: Forecasts (model output)
CREATE TABLE IF NOT EXISTS fact_forecasts (
    forecast_id             BIGINT      AUTO_INCREMENT PRIMARY KEY,
    forecast_date           DATE        NOT NULL,
    product_id              VARCHAR(20) NOT NULL,
    store_id                VARCHAR(20) NOT NULL,
    forecasted_units        INT         NOT NULL DEFAULT 0,
    lower_ci                INT         NOT NULL DEFAULT 0,
    upper_ci                INT         NOT NULL DEFAULT 0,
    model_version           VARCHAR(50) DEFAULT 'RandomForest_v1',
    generated_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES dim_products(product_id),
    FOREIGN KEY (store_id)   REFERENCES dim_stores(store_id),
    INDEX idx_forecast_date (forecast_date),
    UNIQUE KEY uq_forecast (forecast_date, product_id, store_id)
);

-- Fact: Inventory Recommendations
CREATE TABLE IF NOT EXISTS fact_reorder_recommendations (
    rec_id                  BIGINT      AUTO_INCREMENT PRIMARY KEY,
    rec_date                DATE        NOT NULL,
    product_id              VARCHAR(20) NOT NULL,
    store_id                VARCHAR(20) NOT NULL,
    avg_daily_forecast      DECIMAL(10,2),
    total_30d_forecast      INT,
    safety_stock_required   INT,
    reorder_point_recommended INT,
    reorder_qty_recommended INT,
    action                  ENUM('REORDER NOW','SUFFICIENT STOCK') NOT NULL,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES dim_products(product_id),
    FOREIGN KEY (store_id)   REFERENCES dim_stores(store_id)
);


-- ─────────────────────────────────────────
-- ANALYTICAL QUERIES
-- ─────────────────────────────────────────

-- Q1: Monthly revenue trend by category
SELECT
    d.year,
    d.month,
    p.category,
    SUM(fs.revenue)     AS total_revenue,
    SUM(fs.units_sold)  AS total_units,
    ROUND(AVG(fs.unit_price), 2) AS avg_price
FROM fact_sales fs
JOIN dim_date     d ON fs.date_key   = d.date_key
JOIN dim_products p ON fs.product_id = p.product_id
GROUP BY d.year, d.month, p.category
ORDER BY d.year, d.month, total_revenue DESC;


-- Q2: Top 5 products by revenue this year
SELECT
    p.product_id,
    p.product_name,
    p.category,
    SUM(fs.revenue)    AS ytd_revenue,
    SUM(fs.units_sold) AS ytd_units
FROM fact_sales fs
JOIN dim_products p ON fs.product_id = p.product_id
JOIN dim_date     d ON fs.date_key   = d.date_key
WHERE d.year = YEAR(CURDATE())
GROUP BY p.product_id, p.product_name, p.category
ORDER BY ytd_revenue DESC
LIMIT 5;


-- Q3: Week-over-week sales growth per store
WITH weekly_sales AS (
    SELECT
        s.store_id,
        d.year,
        d.week,
        SUM(fs.revenue) AS weekly_revenue
    FROM fact_sales fs
    JOIN dim_date   d ON fs.date_key = d.date_key
    JOIN dim_stores s ON fs.store_id = s.store_id
    GROUP BY s.store_id, d.year, d.week
),
lagged AS (
    SELECT *,
        LAG(weekly_revenue) OVER (PARTITION BY store_id ORDER BY year, week) AS prev_week_revenue
    FROM weekly_sales
)
SELECT
    store_id, year, week, weekly_revenue,
    ROUND(
        (weekly_revenue - prev_week_revenue) / NULLIF(prev_week_revenue, 0) * 100, 2
    ) AS wow_growth_pct
FROM lagged
ORDER BY store_id, year, week;


-- Q4: Products below reorder point (inventory alert)
SELECT
    fi.product_id,
    p.product_name,
    fi.store_id,
    fi.current_stock,
    fi.reorder_point,
    fi.safety_stock,
    fi.lead_time_days,
    (fi.reorder_point - fi.current_stock) AS units_short
FROM fact_inventory fi
JOIN dim_products p ON fi.product_id = p.product_id
WHERE fi.snapshot_date = (SELECT MAX(snapshot_date) FROM fact_inventory)
  AND fi.current_stock <= fi.reorder_point
ORDER BY units_short DESC;


-- Q5: 30-day forecast vs. current stock sufficiency
SELECT
    r.product_id,
    p.product_name,
    r.store_id,
    fi.current_stock,
    r.total_30d_forecast,
    r.reorder_qty_recommended,
    r.action,
    ROUND(fi.current_stock / NULLIF(r.avg_daily_forecast, 0), 1) AS days_of_stock_remaining
FROM fact_reorder_recommendations r
JOIN dim_products  p  ON r.product_id  = p.product_id
JOIN fact_inventory fi ON fi.product_id = r.product_id AND fi.store_id = r.store_id
WHERE r.rec_date = CURDATE()
ORDER BY days_of_stock_remaining ASC;


-- Q6: Weekend vs weekday sales comparison
SELECT
    p.category,
    d.is_weekend,
    ROUND(AVG(fs.units_sold), 2) AS avg_units,
    ROUND(AVG(fs.revenue),    2) AS avg_revenue,
    COUNT(*)                      AS transaction_count
FROM fact_sales fs
JOIN dim_date     d ON fs.date_key   = d.date_key
JOIN dim_products p ON fs.product_id = p.product_id
GROUP BY p.category, d.is_weekend
ORDER BY p.category, d.is_weekend;


-- Q7: Forecast accuracy (actual vs predicted) – rolling 30 days
SELECT
    fs.date_key,
    fs.product_id,
    fs.store_id,
    fs.units_sold               AS actual_units,
    ff.forecasted_units         AS forecast_units,
    ABS(fs.units_sold - ff.forecasted_units) AS abs_error,
    ROUND(
        ABS(fs.units_sold - ff.forecasted_units) / NULLIF(fs.units_sold, 0) * 100, 2
    ) AS ape_pct
FROM fact_sales fs
JOIN fact_forecasts ff
    ON fs.date_key   = ff.forecast_date
   AND fs.product_id = ff.product_id
   AND fs.store_id   = ff.store_id
WHERE fs.date_key >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
ORDER BY ape_pct DESC;


-- Q8: Quarterly revenue ranking by store (window function)
SELECT
    d.year,
    d.quarter,
    s.store_id,
    SUM(fs.revenue) AS quarterly_revenue,
    RANK() OVER (PARTITION BY d.year, d.quarter ORDER BY SUM(fs.revenue) DESC) AS store_rank
FROM fact_sales fs
JOIN dim_date   d ON fs.date_key = d.date_key
JOIN dim_stores s ON fs.store_id = s.store_id
GROUP BY d.year, d.quarter, s.store_id
ORDER BY d.year, d.quarter, store_rank;


-- Q9: Cumulative revenue YTD per product
SELECT
    d.year,
    d.month,
    p.product_id,
    p.product_name,
    SUM(fs.revenue)   AS monthly_revenue,
    SUM(SUM(fs.revenue)) OVER (
        PARTITION BY d.year, p.product_id
        ORDER BY d.month
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS ytd_revenue_cumulative
FROM fact_sales fs
JOIN dim_date     d ON fs.date_key   = d.date_key
JOIN dim_products p ON fs.product_id = p.product_id
GROUP BY d.year, d.month, p.product_id, p.product_name
ORDER BY p.product_id, d.year, d.month;


-- Q10: Holiday impact on sales (Q4 vs rest of year)
SELECT
    p.category,
    CASE WHEN d.is_holiday = 1 THEN 'Holiday Period'
         WHEN d.month IN (11,12) THEN 'Q4 Non-Holiday'
         ELSE 'Rest of Year'
    END AS period_type,
    ROUND(AVG(fs.units_sold), 2)  AS avg_daily_units,
    ROUND(AVG(fs.revenue),    2)  AS avg_daily_revenue,
    COUNT(DISTINCT d.date_key)    AS days_count
FROM fact_sales fs
JOIN dim_date     d ON fs.date_key   = d.date_key
JOIN dim_products p ON fs.product_id = p.product_id
GROUP BY p.category, period_type
ORDER BY p.category, avg_daily_revenue DESC;
