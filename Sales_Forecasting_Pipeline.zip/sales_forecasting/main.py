"""
Sales Forecasting Project - Main Entry Point
Runs the complete pipeline: Data Gen → ETL → Model → Visualizations
"""

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from src.generate_data import generate_sales_data, generate_inventory_data
from src.etl_pipeline import run_etl
from src.forecasting_model import run_forecasting
from src.visualizations import run_visualizations

def main():
    print("=" * 60)
    print("  SALES FORECASTING PIPELINE")
    print("  Random Forest + Medallion Architecture")
    print("=" * 60)

    # Step 1: Generate data
    print("\n[STEP 1] Generating synthetic sales data...")
    os.makedirs("data", exist_ok=True)
    sales_df = generate_sales_data(n_days=730, n_products=5, n_stores=3)
    sales_df.to_csv("data/sales_raw.csv", index=False)
    inventory_df = generate_inventory_data(sales_df)
    inventory_df.to_csv("data/inventory.csv", index=False)
    print(f"  → {len(sales_df):,} rows generated")

    # Step 2: ETL
    print("\n[STEP 2] Running ETL pipeline (Bronze → Silver → Gold)...")
    gold_df = run_etl("data/sales_raw.csv", "data")

    # Step 3: Model
    print("\n[STEP 3] Training Random Forest model + forecasting...")
    model, forecast_df, inventory_recs, cv_metrics, importance_df = run_forecasting(
        "data/gold_features.csv", "data/inventory.csv", "outputs"
    )

    # Step 4: Visualizations
    print("\n[STEP 4] Generating visualizations...")
    run_visualizations("data", "outputs")

    print("\n" + "=" * 60)
    print("  PIPELINE COMPLETE")
    print("  Outputs saved to /outputs/ and /data/")
    print("=" * 60)


if __name__ == "__main__":
    main()
