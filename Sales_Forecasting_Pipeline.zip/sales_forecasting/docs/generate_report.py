"""
Sales Forecasting Project – PDF Report Generator
Uses ReportLab to produce a professional project report
"""

import json, os
import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm, mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, Image, PageBreak
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

# ─── Palette ────────────────────────────────────────
NAVY  = colors.HexColor("#002366")
TEAL  = colors.HexColor("#008080")
LIGHT = colors.HexColor("#E8F4F8")
GRAY  = colors.HexColor("#6C757D")
WHITE = colors.white
BLACK = colors.black

W, H = A4


def build_styles():
    base = getSampleStyleSheet()
    styles = {
        "cover_title": ParagraphStyle("cover_title", fontSize=28, textColor=WHITE,
                                       fontName="Helvetica-Bold", alignment=TA_CENTER, spaceAfter=8),
        "cover_sub":   ParagraphStyle("cover_sub",   fontSize=14, textColor=LIGHT,
                                       fontName="Helvetica",      alignment=TA_CENTER, spaceAfter=6),
        "cover_meta":  ParagraphStyle("cover_meta",  fontSize=11, textColor=LIGHT,
                                       fontName="Helvetica",      alignment=TA_CENTER),
        "h1":   ParagraphStyle("h1",  fontSize=16, textColor=NAVY, fontName="Helvetica-Bold",
                                spaceAfter=6,  spaceBefore=14),
        "h2":   ParagraphStyle("h2",  fontSize=13, textColor=TEAL, fontName="Helvetica-Bold",
                                spaceAfter=4,  spaceBefore=10),
        "body": ParagraphStyle("body", fontSize=10, textColor=BLACK, fontName="Helvetica",
                                spaceAfter=4,  leading=15),
        "bullet": ParagraphStyle("bullet", fontSize=10, textColor=BLACK, fontName="Helvetica",
                                  leftIndent=18, spaceAfter=3, leading=14,
                                  bulletIndent=6, bulletText="•"),
        "caption": ParagraphStyle("caption", fontSize=8, textColor=GRAY, fontName="Helvetica-Oblique",
                                   alignment=TA_CENTER, spaceAfter=6),
        "metric_val": ParagraphStyle("metric_val", fontSize=22, textColor=NAVY, fontName="Helvetica-Bold",
                                      alignment=TA_CENTER),
        "metric_lbl": ParagraphStyle("metric_lbl", fontSize=9,  textColor=GRAY, fontName="Helvetica",
                                      alignment=TA_CENTER),
    }
    return styles


def header_bar(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, H - 1.1*cm, W, 1.1*cm, fill=1, stroke=0)
    canvas.setFillColor(WHITE)
    canvas.setFont("Helvetica-Bold", 9)
    canvas.drawString(1*cm, H - 0.75*cm, "Sales Forecasting Project – Random Forest Pipeline")
    canvas.setFont("Helvetica", 9)
    canvas.drawRightString(W - 1*cm, H - 0.75*cm, f"Page {doc.page}")
    # Footer
    canvas.setFillColor(TEAL)
    canvas.rect(0, 0, W, 0.7*cm, fill=1, stroke=0)
    canvas.setFillColor(WHITE)
    canvas.setFont("Helvetica", 8)
    canvas.drawString(1*cm, 0.22*cm, "Naimuddin  |  Data Analytics")
    canvas.drawRightString(W - 1*cm, 0.22*cm, "Confidential – Internal Use Only")
    canvas.restoreState()


def make_kv_table(rows, s):
    data = [[Paragraph(f"<b>{k}</b>", s["body"]), Paragraph(str(v), s["body"])] for k, v in rows]
    t = Table(data, colWidths=[5.5*cm, 11*cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), LIGHT),
        ("GRID",       (0, 0), (-1,-1), 0.4, colors.HexColor("#CDD9E0")),
        ("ROWBACKGROUNDS", (0,0),(-1,-1), [WHITE, colors.HexColor("#F5FAFC")]),
        ("FONTNAME",   (0, 0), (-1,-1), "Helvetica"),
        ("FONTSIZE",   (0, 0), (-1,-1), 9),
        ("VALIGN",     (0, 0), (-1,-1), "MIDDLE"),
        ("PADDING",    (0, 0), (-1,-1), 6),
    ]))
    return t


def insert_image(path, width=15*cm, caption=None, s=None):
    elems = []
    if os.path.exists(path):
        img = Image(path, width=width, height=width*0.55)
        elems.append(img)
        if caption and s:
            elems.append(Paragraph(caption, s["caption"]))
    return elems


def build_report(output_path="outputs/Sales_Forecasting_Report.pdf"):
    s = build_styles()
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            leftMargin=1.8*cm, rightMargin=1.8*cm,
                            topMargin=1.8*cm, bottomMargin=1.5*cm)
    story = []

    # ─── COVER PAGE ──────────────────────────────────────────
    from reportlab.platypus import FrameBreak
    from reportlab.platypus.flowables import Flowable

    class ColorRect(Flowable):
        def __init__(self, w, h, color):
            Flowable.__init__(self)
            self.width, self.height, self.color = w, h, color
        def draw(self):
            self.canv.setFillColor(self.color)
            self.canv.rect(0, 0, self.width, self.height, fill=1, stroke=0)

    story.append(ColorRect(W - 3.6*cm, 6*cm, NAVY))
    story.append(Spacer(1, 0.4*cm))
    story.append(Paragraph("SALES FORECASTING PROJECT", s["cover_title"]))
    story.append(Paragraph("Time-Series Forecasting Pipeline Using Random Forest", s["cover_sub"]))
    story.append(Spacer(1, 0.3*cm))
    story.append(HRFlowable(width="100%", thickness=2, color=TEAL))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph("Prepared by: Naimuddin", s["cover_meta"]))
    story.append(Paragraph("Role: Data Analytics Professional", s["cover_meta"]))
    story.append(Paragraph("GitHub: github.com/naimuddin  |  Bengaluru, Karnataka", s["cover_meta"]))
    story.append(Paragraph("Date: June 2026", s["cover_meta"]))
    story.append(PageBreak())

    # ─── 1. PROJECT OVERVIEW ─────────────────────────────────
    story.append(Paragraph("1. Project Overview", s["h1"]))
    story.append(HRFlowable(width="100%", thickness=1.5, color=TEAL))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "This project implements a production-grade <b>Sales Forecasting Pipeline</b> that leverages "
        "Random Forest regression to predict daily sales volumes across multiple product-store combinations. "
        "The pipeline is built on a <b>Medallion Architecture</b> (Bronze → Silver → Gold) and delivers "
        "actionable inventory reorder recommendations, reducing overstock and stockout risk.",
        s["body"]
    ))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph("Business Objectives", s["h2"]))
    for bullet in [
        "Forecast 30-day sales volumes per product-store with confidence intervals",
        "Identify seasonal and promotional demand patterns using historical time-series data",
        "Automate inventory reorder recommendations based on forecast + lead time logic",
        "Build a reusable, containerized pipeline with Docker for production deployment",
        "Provide interactive SQL analytics layer for business intelligence reporting",
    ]:
        story.append(Paragraph(bullet, s["bullet"]))
    story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph("Technical Stack", s["h2"]))
    story.append(make_kv_table([
        ("Language", "Python 3.11"),
        ("ML Framework", "scikit-learn – RandomForestRegressor (n_estimators=200, max_depth=12)"),
        ("Data Processing", "Pandas 2.x, NumPy 1.26"),
        ("Visualization", "Matplotlib 3.9, Seaborn 0.13"),
        ("Database", "MySQL 8.0 – Star Schema (fact + dim tables)"),
        ("Containerization", "Docker 24 + Docker Compose 3.9"),
        ("Architecture", "Medallion (Bronze / Silver / Gold)"),
        ("Validation", "TimeSeriesSplit 5-fold cross-validation"),
    ], s))

    story.append(PageBreak())

    # ─── 2. DATA PIPELINE ────────────────────────────────────
    story.append(Paragraph("2. ETL Pipeline – Medallion Architecture", s["h1"]))
    story.append(HRFlowable(width="100%", thickness=1.5, color=TEAL))
    story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph("Bronze Layer – Raw Ingestion", s["h2"]))
    story.append(Paragraph(
        "Raw CSV sales data is ingested with schema validation, null detection, and clipping of "
        "negative sales values. <b>10,950 rows</b> covering 730 days × 5 products × 3 stores were generated "
        "using a realistic synthetic model incorporating trend, weekly seasonality, annual cycles, "
        "and holiday demand spikes.", s["body"]
    ))

    story.append(Paragraph("Silver Layer – Cleaning & Enrichment", s["h2"]))
    for b in [
        "Deduplication on (date, product_id, store_id) composite key",
        "Calendar feature derivation: year, month, quarter, week, day_of_week, is_weekend, is_month_end",
        "Holiday flagging: Black Friday, Christmas, New Year periods",
        "Revenue recalculation validation (units_sold × unit_price vs recorded revenue)",
    ]:
        story.append(Paragraph(b, s["bullet"]))

    story.append(Paragraph("Gold Layer – Feature Engineering", s["h2"]))
    for b in [
        "Lag features: lag_1d, lag_7d, lag_14d, lag_28d (demand history with no leakage)",
        "Rolling statistics: 7/14/30-day rolling mean and standard deviation",
        "Momentum: 7-day cumulative sales sum",
        "Label encoding: product_id and store_id → integer codes",
        "Final Gold dataset: 10,530 ML-ready rows (after lag warm-up period removed)",
    ]:
        story.append(Paragraph(b, s["bullet"]))

    story.append(PageBreak())

    # ─── 3. MODEL ────────────────────────────────────────────
    story.append(Paragraph("3. Forecasting Model", s["h1"]))
    story.append(HRFlowable(width="100%", thickness=1.5, color=TEAL))
    story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph("Algorithm: Random Forest Regressor", s["h2"]))
    story.append(Paragraph(
        "Random Forest was selected for its robustness to outliers, ability to capture non-linear "
        "seasonal patterns, and built-in feature importance ranking. Time-series integrity was "
        "maintained using <b>TimeSeriesSplit</b> (5 folds) to prevent data leakage.", s["body"]
    ))
    story.append(Spacer(1, 0.2*cm))

    # CV Metrics table
    try:
        cv_df = pd.read_csv("outputs/cv_metrics.csv")
        cv_data = [["Fold", "MAE", "RMSE", "R²", "MAPE %"]]
        for _, row in cv_df.iterrows():
            cv_data.append([
                str(int(row["fold"])),
                f"{row['MAE']:.1f}",
                f"{row['RMSE']:.1f}",
                f"{row['R2']:.3f}",
                f"{row['MAPE']:.1f}%",
            ])
        cv_data.append([
            "Average",
            f"{cv_df['MAE'].mean():.1f}",
            f"{cv_df['RMSE'].mean():.1f}",
            f"{cv_df['R2'].mean():.3f}",
            f"{cv_df['MAPE'].mean():.1f}%",
        ])
        cv_table = Table(cv_data, colWidths=[2.5*cm, 3*cm, 3*cm, 3*cm, 3*cm])
        cv_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), NAVY),
            ("TEXTCOLOR",  (0,0), (-1,0), WHITE),
            ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
            ("BACKGROUND", (0,-1),(-1,-1), TEAL),
            ("TEXTCOLOR",  (0,-1),(-1,-1), WHITE),
            ("FONTNAME",   (0,-1),(-1,-1), "Helvetica-Bold"),
            ("ROWBACKGROUNDS", (0,1),(-1,-2), [WHITE, LIGHT]),
            ("ALIGN",      (0,0), (-1,-1), "CENTER"),
            ("FONTSIZE",   (0,0), (-1,-1), 10),
            ("GRID",       (0,0), (-1,-1), 0.5, colors.HexColor("#CDD9E0")),
            ("PADDING",    (0,0), (-1,-1), 7),
        ]))
        story.append(cv_table)
        story.append(Paragraph("Table 1: Cross-Validation Metrics per Fold", s["caption"]))
    except:
        pass

    story.append(Spacer(1, 0.3*cm))
    story += insert_image("outputs/chart_model_performance.png", caption="Figure 1: CV Error Metrics (MAE/RMSE) and R² per Fold", s=s)
    story += insert_image("outputs/chart_feature_importance.png", caption="Figure 2: Top Feature Importances", s=s)

    story.append(PageBreak())

    # ─── 4. SALES INSIGHTS ───────────────────────────────────
    story.append(Paragraph("4. Sales Insights & Seasonality", s["h1"]))
    story.append(HRFlowable(width="100%", thickness=1.5, color=TEAL))
    story += insert_image("outputs/chart_sales_overview.png", caption="Figure 3: Daily Revenue Trend and 7-Day Rolling Average", s=s)
    story += insert_image("outputs/chart_seasonality.png", caption="Figure 4: Seasonality by Month, Day of Week, and Quarter", s=s)

    story.append(PageBreak())

    # ─── 5. FORECAST ─────────────────────────────────────────
    story.append(Paragraph("5. 30-Day Forecast & Inventory Optimization", s["h1"]))
    story.append(HRFlowable(width="100%", thickness=1.5, color=TEAL))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "The final Random Forest model generates 30-day forward-looking forecasts with 95% confidence "
        "intervals for all 15 product-store combinations. Inventory reorder recommendations are computed "
        "by comparing the total 30-day forecast against current stock levels, accounting for safety stock "
        "buffers and supplier lead time.", s["body"]
    ))
    story += insert_image("outputs/chart_forecast_30d.png", caption="Figure 5: 30-Day Sales Forecast with 95% CI (Top 3 Product-Store Combos)", s=s)
    story += insert_image("outputs/chart_inventory_actions.png", caption="Figure 6: Inventory Reorder Recommendations", s=s)

    story.append(PageBreak())

    # ─── 6. SQL SCHEMA ───────────────────────────────────────
    story.append(Paragraph("6. Database Schema & Analytics", s["h1"]))
    story.append(HRFlowable(width="100%", thickness=1.5, color=TEAL))
    story.append(Spacer(1, 0.3*cm))
    story.append(make_kv_table([
        ("dim_products",   "Product attributes – ID, name, category, unit cost"),
        ("dim_stores",     "Store attributes – ID, region, city"),
        ("dim_date",       "Calendar dimension with holiday and season flags"),
        ("fact_sales",     "Daily sales transactions (units, price, revenue)"),
        ("fact_inventory", "Snapshot inventory levels per product-store"),
        ("fact_forecasts", "Model-generated 30-day forecasts with CI bounds"),
        ("fact_reorder_recommendations", "Inventory optimization actions"),
    ], s))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph("10 analytical SQL queries included:", s["h2"]))
    for q in [
        "Monthly revenue trend by category", "Top 5 products by YTD revenue",
        "Week-over-week growth per store (LAG window function)",
        "Products below reorder point (inventory alert)",
        "30-day forecast vs current stock sufficiency",
        "Weekend vs weekday sales comparison",
        "Forecast accuracy: actual vs predicted MAPE",
        "Quarterly store revenue ranking (RANK window function)",
        "Cumulative YTD revenue per product (SUM OVER)",
        "Holiday impact analysis (Q4 vs rest of year)",
    ]:
        story.append(Paragraph(q, s["bullet"]))

    story.append(PageBreak())

    # ─── 7. DELIVERABLES ─────────────────────────────────────
    story.append(Paragraph("7. Deliverables & Project Structure", s["h1"]))
    story.append(HRFlowable(width="100%", thickness=1.5, color=TEAL))
    story.append(Spacer(1, 0.3*cm))
    story.append(make_kv_table([
        ("src/generate_data.py",      "Synthetic sales & inventory data generator"),
        ("src/etl_pipeline.py",       "Bronze → Silver → Gold ETL pipeline"),
        ("src/forecasting_model.py",  "Random Forest training, CV, forecast, inventory logic"),
        ("src/visualizations.py",     "6 analytical chart modules"),
        ("sql/schema_and_queries.sql","MySQL star schema + 10 analytical SQL queries"),
        ("docker/Dockerfile",         "Python 3.11 slim container"),
        ("docker/docker-compose.yml", "Pipeline + MySQL 8.0 orchestration"),
        ("outputs/",                  "CSV exports, charts, model summary JSON"),
        ("main.py",                   "Full pipeline runner"),
    ], s))

    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width="100%", thickness=2, color=TEAL))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "This project demonstrates end-to-end ownership of a production ML forecasting pipeline — "
        "from synthetic data engineering and feature-rich ETL to model training with rigorous "
        "time-series CV, actionable inventory optimization, and a fully containerized deployment. "
        "The SQL analytics layer enables direct BI tool integration for stakeholder reporting.",
        s["body"]
    ))

    doc.build(story, onFirstPage=header_bar, onLaterPages=header_bar)
    print(f"PDF saved: {output_path}")


if __name__ == "__main__":
    os.makedirs("outputs", exist_ok=True)
    build_report()
