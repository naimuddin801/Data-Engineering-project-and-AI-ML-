"""
Sales Forecasting Project - Visualization Module
Generates charts for EDA, model evaluation, and forecast reporting
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import json, os

# Style
plt.rcParams.update({
    "figure.facecolor": "#F8F9FA",
    "axes.facecolor": "#FFFFFF",
    "axes.grid": True,
    "grid.alpha": 0.4,
    "font.family": "DejaVu Sans",
    "axes.spines.top": False,
    "axes.spines.right": False
})
NAVY   = "#002366"
TEAL   = "#008080"
ORANGE = "#E07B39"
GRAY   = "#6C757D"


def plot_sales_overview(silver_df: pd.DataFrame, output_dir: str):
    """Time-series overview: total daily sales + by category."""
    fig, axes = plt.subplots(2, 1, figsize=(14, 8))
    fig.suptitle("Sales Overview – Daily Revenue Trends", fontsize=16, fontweight="bold", color=NAVY, y=0.98)

    daily = silver_df.groupby("date")["revenue"].sum().reset_index()
    daily["rolling_7d"] = daily["revenue"].rolling(7).mean()

    axes[0].fill_between(daily["date"], daily["revenue"], alpha=0.25, color=TEAL)
    axes[0].plot(daily["date"], daily["revenue"], color=TEAL, linewidth=0.8, alpha=0.6, label="Daily Revenue")
    axes[0].plot(daily["date"], daily["rolling_7d"], color=NAVY, linewidth=2, label="7-Day Rolling Avg")
    axes[0].set_title("Total Daily Revenue", fontsize=12, color=NAVY)
    axes[0].set_ylabel("Revenue (₹)", fontsize=10)
    axes[0].legend()
    axes[0].yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"₹{x/1e6:.1f}M"))

    cat_daily = silver_df.groupby(["date", "category"])["revenue"].sum().reset_index()
    for cat in cat_daily["category"].unique():
        sub = cat_daily[cat_daily["category"] == cat]
        axes[1].plot(sub["date"], sub["revenue"].rolling(14).mean(), linewidth=2, label=cat)
    axes[1].set_title("14-Day Rolling Revenue by Category", fontsize=12, color=NAVY)
    axes[1].set_ylabel("Revenue (₹)", fontsize=10)
    axes[1].legend(fontsize=9)
    axes[1].yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"₹{x/1e6:.1f}M"))

    plt.tight_layout()
    path = f"{output_dir}/chart_sales_overview.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {path}")


def plot_seasonality(silver_df: pd.DataFrame, output_dir: str):
    """Seasonality analysis: monthly, weekly, and quarterly patterns."""
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    fig.suptitle("Seasonality Patterns – Units Sold", fontsize=15, fontweight="bold", color=NAVY)

    # Monthly
    monthly = silver_df.groupby("month")["units_sold"].mean().reset_index()
    month_names = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    axes[0].bar(monthly["month"], monthly["units_sold"], color=TEAL, edgecolor="white")
    axes[0].set_xticks(range(1,13))
    axes[0].set_xticklabels(month_names, rotation=45, fontsize=8)
    axes[0].set_title("Avg Units by Month", color=NAVY, fontweight="bold")
    axes[0].set_ylabel("Avg Units Sold")

    # Weekly
    weekly = silver_df.groupby("day_of_week")["units_sold"].mean().reset_index()
    day_names = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
    colors_wk = [ORANGE if d >= 5 else TEAL for d in weekly["day_of_week"]]
    axes[1].bar(weekly["day_of_week"], weekly["units_sold"], color=colors_wk, edgecolor="white")
    axes[1].set_xticks(range(7))
    axes[1].set_xticklabels(day_names)
    axes[1].set_title("Avg Units by Day of Week", color=NAVY, fontweight="bold")

    # Quarterly
    quarterly = silver_df.groupby("quarter")["revenue"].sum().reset_index()
    axes[2].bar([f"Q{q}" for q in quarterly["quarter"]], quarterly["revenue"]/1e6,
                color=[NAVY, TEAL, ORANGE, GRAY], edgecolor="white")
    axes[2].set_title("Total Revenue by Quarter", color=NAVY, fontweight="bold")
    axes[2].set_ylabel("Revenue (₹M)")

    plt.tight_layout()
    path = f"{output_dir}/chart_seasonality.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {path}")


def plot_model_performance(cv_metrics: pd.DataFrame, output_dir: str):
    """CV metrics across folds."""
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Random Forest – Cross-Validation Performance", fontsize=14, fontweight="bold", color=NAVY)

    # MAE / RMSE per fold
    x = cv_metrics["fold"]
    axes[0].plot(x, cv_metrics["MAE"],  "o-", color=TEAL,   linewidth=2, markersize=8, label="MAE")
    axes[0].plot(x, cv_metrics["RMSE"], "s-", color=ORANGE, linewidth=2, markersize=8, label="RMSE")
    axes[0].axhline(cv_metrics["MAE"].mean(),  color=TEAL,   linestyle="--", alpha=0.6)
    axes[0].axhline(cv_metrics["RMSE"].mean(), color=ORANGE, linestyle="--", alpha=0.6)
    axes[0].set_title("Error Metrics per CV Fold", color=NAVY, fontweight="bold")
    axes[0].set_xlabel("Fold")
    axes[0].set_ylabel("Error (units)")
    axes[0].legend()
    axes[0].set_xticks(x)

    # R² and MAPE
    ax2 = axes[1].twinx()
    axes[1].bar(x - 0.2, cv_metrics["R2"],   width=0.35, color=NAVY,   label="R²", alpha=0.85)
    ax2.bar(    x + 0.2, cv_metrics["MAPE"], width=0.35, color=ORANGE, label="MAPE %", alpha=0.85)
    axes[1].set_title("R² and MAPE per Fold", color=NAVY, fontweight="bold")
    axes[1].set_xlabel("Fold")
    axes[1].set_ylabel("R²", color=NAVY)
    ax2.set_ylabel("MAPE %", color=ORANGE)
    axes[1].set_xticks(x)
    axes[1].legend(loc="upper left")
    ax2.legend(loc="upper right")

    plt.tight_layout()
    path = f"{output_dir}/chart_model_performance.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {path}")


def plot_feature_importance(importance_df: pd.DataFrame, output_dir: str):
    """Horizontal bar chart of top feature importances."""
    fig, ax = plt.subplots(figsize=(10, 7))
    colors = [NAVY if i < 5 else TEAL if i < 10 else GRAY for i in range(len(importance_df))]
    ax.barh(importance_df["feature"][::-1], importance_df["importance"][::-1], color=colors[::-1])
    ax.set_title("Top Feature Importances – Random Forest", fontsize=14, fontweight="bold", color=NAVY)
    ax.set_xlabel("Importance Score")
    for i, (_, row) in enumerate(importance_df[::-1].iterrows()):
        ax.text(row["importance"] + 0.001, i, f"{row['importance']:.3f}", va="center", fontsize=9, color=GRAY)
    plt.tight_layout()
    path = f"{output_dir}/chart_feature_importance.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {path}")


def plot_forecast(forecast_df: pd.DataFrame, output_dir: str, n_combos: int = 3):
    """Forecast charts for top n product-store combos."""
    combos = forecast_df.groupby(["product_id","store_id"])["forecasted_units"].sum().nlargest(n_combos).index
    fig, axes = plt.subplots(n_combos, 1, figsize=(13, 4*n_combos))
    fig.suptitle("30-Day Sales Forecast with 95% Confidence Interval", fontsize=14, fontweight="bold", color=NAVY)
    
    for i, (prod, store) in enumerate(combos):
        ax = axes[i] if n_combos > 1 else axes
        sub = forecast_df[(forecast_df["product_id"]==prod) & (forecast_df["store_id"]==store)].copy()
        sub["forecast_date"] = pd.to_datetime(sub["forecast_date"])
        ax.plot(sub["forecast_date"], sub["forecasted_units"], color=NAVY, linewidth=2, marker="o", markersize=4)
        ax.fill_between(sub["forecast_date"], sub["lower_ci"], sub["upper_ci"], alpha=0.2, color=TEAL, label="95% CI")
        ax.set_title(f"{prod} | {store}", color=NAVY, fontweight="bold", fontsize=11)
        ax.set_ylabel("Forecasted Units")
        ax.legend()
    
    plt.tight_layout()
    path = f"{output_dir}/chart_forecast_30d.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {path}")


def plot_inventory_actions(inventory_recs: pd.DataFrame, output_dir: str):
    """Inventory recommendation summary."""
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    fig.suptitle("Inventory Optimization Recommendations", fontsize=14, fontweight="bold", color=NAVY)

    action_counts = inventory_recs["action"].value_counts()
    colors = [ORANGE if a == "REORDER NOW" else TEAL for a in action_counts.index]
    axes[0].pie(action_counts.values, labels=action_counts.index, colors=colors,
                autopct="%1.1f%%", startangle=90, textprops={"fontsize":11})
    axes[0].set_title("Stock Status Distribution", color=NAVY, fontweight="bold")

    reorder = inventory_recs[inventory_recs["action"] == "REORDER NOW"].nlargest(10, "reorder_qty_recommended")
    if len(reorder) > 0:
        labels = reorder["product_id"] + "\n" + reorder["store_id"]
        axes[1].barh(labels[::-1], reorder["reorder_qty_recommended"][::-1], color=ORANGE, edgecolor="white")
        axes[1].set_title("Top 10 Reorder Quantities", color=NAVY, fontweight="bold")
        axes[1].set_xlabel("Units to Reorder")

    plt.tight_layout()
    path = f"{output_dir}/chart_inventory_actions.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {path}")


def run_visualizations(data_dir: str = "data", output_dir: str = "outputs"):
    os.makedirs(output_dir, exist_ok=True)
    print("\n[VIZ] Generating charts...")
    
    silver_df    = pd.read_csv(f"{data_dir}/silver_sales.csv", parse_dates=["date"])
    cv_metrics   = pd.read_csv(f"{output_dir}/cv_metrics.csv")
    importance_df = pd.read_csv(f"{output_dir}/feature_importance.csv")
    forecast_df  = pd.read_csv(f"{output_dir}/sales_forecast_30d.csv")
    inventory_recs = pd.read_csv(f"{output_dir}/inventory_recommendations.csv")

    plot_sales_overview(silver_df, output_dir)
    plot_seasonality(silver_df, output_dir)
    plot_model_performance(cv_metrics, output_dir)
    plot_feature_importance(importance_df, output_dir)
    plot_forecast(forecast_df, output_dir)
    plot_inventory_actions(inventory_recs, output_dir)
    print("[VIZ] All charts saved.")


if __name__ == "__main__":
    run_visualizations()
