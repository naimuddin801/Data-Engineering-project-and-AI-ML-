"""
Sales Forecasting Project - ETL Pipeline
Transforms raw sales data through Bronze → Silver → Gold layers (Medallion Architecture)
"""

import pandas as pd
import numpy as np
import os
from datetime import datetime

# ─────────────────────────────────────────
# BRONZE LAYER: Raw ingestion + validation
# ─────────────────────────────────────────

def bronze_ingest(filepath: str) -> pd.DataFrame:
    """Load raw CSV and apply schema validation."""
    print("[BRONZE] Ingesting raw data...")
    df = pd.read_csv(filepath, parse_dates=["date"])
    
    required_cols = ["date", "product_id", "store_id", "units_sold", "unit_price", "revenue"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    
    # Basic data quality checks
    null_count = df.isnull().sum().sum()
    neg_sales = (df["units_sold"] < 0).sum()
    print(f"  → Rows: {len(df):,} | Nulls: {null_count} | Negative sales: {neg_sales}")
    
    df = df.dropna(subset=required_cols)
    df["units_sold"] = df["units_sold"].clip(lower=0)
    
    return df


# ─────────────────────────────────────────
# SILVER LAYER: Cleaning + enrichment
# ─────────────────────────────────────────

def silver_transform(df: pd.DataFrame) -> pd.DataFrame:
    """Clean, deduplicate, and enrich the dataset."""
    print("[SILVER] Transforming data...")
    df = df.drop_duplicates(subset=["date", "product_id", "store_id"])
    
    # Calendar features
    df["year"]         = df["date"].dt.year
    df["month"]        = df["date"].dt.month
    df["quarter"]      = df["date"].dt.quarter
    df["week"]         = df["date"].dt.isocalendar().week.astype(int)
    df["day_of_week"]  = df["date"].dt.dayofweek        # 0=Mon, 6=Sun
    df["is_weekend"]   = (df["day_of_week"] >= 5).astype(int)
    df["day_of_year"]  = df["date"].dt.dayofyear
    df["is_month_end"] = df["date"].dt.is_month_end.astype(int)
    
    # Seasonal flags
    df["is_q4_holiday"] = (
        ((df["month"] == 11) & (df["date"].dt.day >= 25)) |
        ((df["month"] == 12) & (df["date"].dt.day >= 20))
    ).astype(int)
    
    # Revenue validation
    df["revenue_calc"]   = df["units_sold"] * df["unit_price"]
    df["revenue_delta"]  = (df["revenue"] - df["revenue_calc"]).abs()
    df["revenue"]        = df["revenue_calc"]  # Use calculated value
    
    print(f"  → Rows after dedup: {len(df):,}")
    return df


# ─────────────────────────────────────────
# GOLD LAYER: Feature engineering for ML
# ─────────────────────────────────────────

def gold_feature_engineer(df: pd.DataFrame, target_col: str = "units_sold") -> pd.DataFrame:
    """Build ML-ready features with lag variables, rolling stats, and encoding."""
    print("[GOLD] Engineering features...")
    df = df.sort_values(["product_id", "store_id", "date"]).copy()
    
    group_key = ["product_id", "store_id"]
    
    # ─ Lag features ─
    for lag in [1, 7, 14, 28]:
        col = f"lag_{lag}d"
        df[col] = df.groupby(group_key)[target_col].shift(lag)
    
    # ─ Rolling statistics ─
    for window in [7, 14, 30]:
        df[f"rolling_mean_{window}d"] = (
            df.groupby(group_key)[target_col]
            .transform(lambda x: x.shift(1).rolling(window=window, min_periods=1).mean())
        )
        df[f"rolling_std_{window}d"] = (
            df.groupby(group_key)[target_col]
            .transform(lambda x: x.shift(1).rolling(window=window, min_periods=1).std().fillna(0))
        )
    
    # ─ Momentum features ─
    df["sales_7d_sum"] = (
        df.groupby(group_key)[target_col]
        .transform(lambda x: x.shift(1).rolling(7, min_periods=1).sum())
    )
    
    # ─ Label encoding ─
    df["product_enc"] = df["product_id"].astype("category").cat.codes
    df["store_enc"]   = df["store_id"].astype("category").cat.codes
    
    df_clean = df.dropna(subset=[f"lag_{lag}d" for lag in [1, 7, 14, 28]])
    print(f"  → Feature rows ready: {len(df_clean):,}")
    return df_clean


# ─────────────────────────────────────────
# AGGREGATIONS: Gold summary tables
# ─────────────────────────────────────────

def build_gold_aggregates(df: pd.DataFrame) -> dict:
    """Build analytical aggregate tables for dashboards."""
    # Monthly product-level summary
    monthly = (
        df.groupby(["year", "month", "product_id", "category"])
        .agg(total_units=("units_sold", "sum"), total_revenue=("revenue", "sum"), avg_price=("unit_price", "mean"))
        .reset_index()
    )
    
    # Store-level weekly summary
    weekly_store = (
        df.groupby(["year", "week", "store_id"])
        .agg(total_units=("units_sold", "sum"), total_revenue=("revenue", "sum"))
        .reset_index()
    )
    
    # Category quarterly revenue
    category_q = (
        df.groupby(["year", "quarter", "category"])
        .agg(total_revenue=("revenue", "sum"), total_units=("units_sold", "sum"))
        .reset_index()
    )
    
    return {
        "monthly_product": monthly,
        "weekly_store": weekly_store,
        "category_quarterly": category_q
    }


# ─────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────

def run_etl(raw_path: str = "data/sales_raw.csv", output_dir: str = "data"):
    os.makedirs(output_dir, exist_ok=True)
    start = datetime.now()
    
    bronze_df = bronze_ingest(raw_path)
    silver_df = silver_transform(bronze_df)
    gold_df   = gold_feature_engineer(silver_df)
    aggregates = build_gold_aggregates(silver_df)
    
    # Save layers
    bronze_df.to_csv(f"{output_dir}/bronze_sales.csv", index=False)
    silver_df.to_csv(f"{output_dir}/silver_sales.csv", index=False)
    gold_df.to_csv(f"{output_dir}/gold_features.csv", index=False)
    
    for name, agg_df in aggregates.items():
        agg_df.to_csv(f"{output_dir}/gold_{name}.csv", index=False)
    
    elapsed = (datetime.now() - start).total_seconds()
    print(f"\nETL Pipeline complete in {elapsed:.1f}s")
    print(f"  Bronze: {len(bronze_df):,} rows")
    print(f"  Silver: {len(silver_df):,} rows")
    print(f"  Gold:   {len(gold_df):,} rows (with ML features)")
    
    return gold_df


if __name__ == "__main__":
    run_etl()
