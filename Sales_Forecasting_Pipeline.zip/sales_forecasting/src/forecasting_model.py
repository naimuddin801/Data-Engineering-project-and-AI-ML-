"""
Sales Forecasting Project - Random Forest Forecasting Model
Time-series forecasting using sklearn RandomForestRegressor with lag features
"""

import pandas as pd
import numpy as np
import os
import json
from datetime import datetime

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings("ignore")


# ─────────────────────────────────────────
# FEATURE SELECTION
# ─────────────────────────────────────────

FEATURE_COLS = [
    "month", "quarter", "week", "day_of_week", "is_weekend",
    "day_of_year", "is_month_end", "is_q4_holiday",
    "product_enc", "store_enc",
    "lag_1d", "lag_7d", "lag_14d", "lag_28d",
    "rolling_mean_7d", "rolling_mean_14d", "rolling_mean_30d",
    "rolling_std_7d", "rolling_std_14d", "rolling_std_30d",
    "sales_7d_sum"
]
TARGET_COL = "units_sold"


# ─────────────────────────────────────────
# MODEL TRAINING
# ─────────────────────────────────────────

def train_model(df: pd.DataFrame, n_splits: int = 5):
    """Train Random Forest with time-series cross-validation."""
    print("\n[MODEL] Training Random Forest Forecaster...")
    
    df = df.sort_values("date").copy()
    X = df[FEATURE_COLS].fillna(0)
    y = df[TARGET_COL]
    
    # Time-series split (no data leakage)
    tscv = TimeSeriesSplit(n_splits=n_splits)
    
    cv_metrics = []
    for fold, (train_idx, val_idx) in enumerate(tscv.split(X)):
        X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
        y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
        
        model = RandomForestRegressor(
            n_estimators=200,
            max_depth=12,
            min_samples_leaf=5,
            max_features="sqrt",
            random_state=42,
            n_jobs=-1
        )
        model.fit(X_train, y_train)
        y_pred = model.predict(X_val)
        
        mae  = mean_absolute_error(y_val, y_pred)
        rmse = np.sqrt(mean_squared_error(y_val, y_pred))
        r2   = r2_score(y_val, y_pred)
        mape = np.mean(np.abs((y_val - y_pred) / (y_val + 1e-9))) * 100
        
        cv_metrics.append({"fold": fold+1, "MAE": mae, "RMSE": rmse, "R2": r2, "MAPE": mape})
        print(f"  Fold {fold+1}: MAE={mae:.1f} | RMSE={rmse:.1f} | R²={r2:.3f} | MAPE={mape:.1f}%")
    
    # Final model on all data
    final_model = RandomForestRegressor(
        n_estimators=200, max_depth=12, min_samples_leaf=5,
        max_features="sqrt", random_state=42, n_jobs=-1
    )
    final_model.fit(X, y)
    
    cv_df = pd.DataFrame(cv_metrics)
    print(f"\n  Avg MAE:  {cv_df['MAE'].mean():.1f} ± {cv_df['MAE'].std():.1f}")
    print(f"  Avg RMSE: {cv_df['RMSE'].mean():.1f} ± {cv_df['RMSE'].std():.1f}")
    print(f"  Avg R²:   {cv_df['R2'].mean():.3f}")
    print(f"  Avg MAPE: {cv_df['MAPE'].mean():.1f}%")
    
    return final_model, cv_df


# ─────────────────────────────────────────
# FEATURE IMPORTANCE
# ─────────────────────────────────────────

def get_feature_importance(model, top_n: int = 15) -> pd.DataFrame:
    """Extract and rank feature importances."""
    importance = pd.DataFrame({
        "feature": FEATURE_COLS,
        "importance": model.feature_importances_
    }).sort_values("importance", ascending=False).head(top_n)
    return importance


# ─────────────────────────────────────────
# FORECASTING
# ─────────────────────────────────────────

def generate_forecast(model, df: pd.DataFrame, forecast_days: int = 30) -> pd.DataFrame:
    """Generate 30-day forward forecasts per product-store combination."""
    print(f"\n[FORECAST] Generating {forecast_days}-day forecasts...")
    
    df = df.sort_values("date").copy()
    X = df[FEATURE_COLS].fillna(0)
    df["predicted_units"] = model.predict(X).clip(min=0).round().astype(int)
    
    # Build forecast horizon summary
    last_date = df["date"].max()
    forecast_rows = []
    
    for (product_id, store_id), group in df.groupby(["product_id", "store_id"]):
        recent = group.tail(30)
        avg_recent = recent["predicted_units"].mean()
        std_recent = recent["predicted_units"].std()
        
        for d in range(1, forecast_days + 1):
            forecast_date = last_date + pd.Timedelta(days=d)
            # Simple extrapolation with trend noise
            point_forecast = max(0, avg_recent + np.random.normal(0, std_recent * 0.2))
            lower_ci = max(0, point_forecast - 1.96 * std_recent)
            upper_ci = point_forecast + 1.96 * std_recent
            
            forecast_rows.append({
                "forecast_date": forecast_date.strftime("%Y-%m-%d"),
                "product_id": product_id,
                "store_id": store_id,
                "forecasted_units": round(point_forecast),
                "lower_ci": round(lower_ci),
                "upper_ci": round(upper_ci),
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
    
    forecast_df = pd.DataFrame(forecast_rows)
    print(f"  → Forecast rows: {len(forecast_df):,}")
    return forecast_df


# ─────────────────────────────────────────
# INVENTORY OPTIMIZATION
# ─────────────────────────────────────────

def optimize_inventory(forecast_df: pd.DataFrame, inventory_df: pd.DataFrame) -> pd.DataFrame:
    """Calculate optimal reorder quantities based on forecasts."""
    print("\n[INVENTORY] Optimizing reorder recommendations...")
    
    summary = (
        forecast_df.groupby(["product_id", "store_id"])
        .agg(
            avg_daily_forecast=("forecasted_units", "mean"),
            total_30d_forecast=("forecasted_units", "sum"),
            max_daily_forecast=("forecasted_units", "max"),
            forecast_std=("forecasted_units", "std")
        )
        .reset_index()
    )
    
    merged = summary.merge(inventory_df, on=["product_id", "store_id"], how="left")
    
    # EOQ and reorder logic
    merged["safety_stock_required"] = (
        merged["forecast_std"] * 1.65 * np.sqrt(merged["lead_time_days"].fillna(7))
    ).round()
    merged["reorder_point_recommended"] = (
        merged["avg_daily_forecast"] * merged["lead_time_days"].fillna(7)
        + merged["safety_stock_required"]
    ).round()
    merged["reorder_qty_recommended"] = (
        merged["total_30d_forecast"] - merged["current_stock"].fillna(0)
    ).clip(lower=0).round()
    merged["action"] = merged["reorder_qty_recommended"].apply(
        lambda x: "REORDER NOW" if x > 0 else "SUFFICIENT STOCK"
    )
    
    action_counts = merged["action"].value_counts()
    for action, count in action_counts.items():
        print(f"  → {action}: {count} product-store combos")
    
    return merged


# ─────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────

def run_forecasting(data_path: str = "data/gold_features.csv",
                    inventory_path: str = "data/inventory.csv",
                    output_dir: str = "outputs"):
    os.makedirs(output_dir, exist_ok=True)
    
    df = pd.read_csv(data_path, parse_dates=["date"])
    inventory_df = pd.read_csv(inventory_path)
    
    model, cv_metrics = train_model(df)
    importance_df = get_feature_importance(model)
    forecast_df = generate_forecast(model, df, forecast_days=30)
    inventory_recs = optimize_inventory(forecast_df, inventory_df)
    
    # Save outputs
    cv_metrics.to_csv(f"{output_dir}/cv_metrics.csv", index=False)
    importance_df.to_csv(f"{output_dir}/feature_importance.csv", index=False)
    forecast_df.to_csv(f"{output_dir}/sales_forecast_30d.csv", index=False)
    inventory_recs.to_csv(f"{output_dir}/inventory_recommendations.csv", index=False)
    
    # Model summary JSON
    summary = {
        "model": "RandomForestRegressor",
        "n_estimators": 200,
        "max_depth": 12,
        "features_used": len(FEATURE_COLS),
        "cv_folds": 5,
        "avg_mae": round(cv_metrics["MAE"].mean(), 2),
        "avg_rmse": round(cv_metrics["RMSE"].mean(), 2),
        "avg_r2": round(cv_metrics["R2"].mean(), 4),
        "avg_mape_pct": round(cv_metrics["MAPE"].mean(), 2),
        "forecast_horizon_days": 30,
        "run_timestamp": datetime.now().isoformat()
    }
    with open(f"{output_dir}/model_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    
    print("\n[DONE] All outputs saved to /outputs/")
    return model, forecast_df, inventory_recs, cv_metrics, importance_df


if __name__ == "__main__":
    run_forecasting()
