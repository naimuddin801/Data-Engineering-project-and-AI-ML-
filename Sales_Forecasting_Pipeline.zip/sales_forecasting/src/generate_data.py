"""
Sales Forecasting Project - Synthetic Data Generator
Generates realistic retail sales time-series data for forecasting pipeline
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

np.random.seed(42)

def generate_sales_data(n_days=730, n_products=5, n_stores=3):
    """Generate synthetic daily sales data with trend, seasonality, and noise."""
    
    start_date = datetime(2022, 1, 1)
    dates = [start_date + timedelta(days=i) for i in range(n_days)]
    
    products = [f"PROD_{str(i).zfill(3)}" for i in range(1, n_products+1)]
    product_names = {
        "PROD_001": "Electronics - Laptop",
        "PROD_002": "Electronics - Headphones",
        "PROD_003": "Apparel - Jacket",
        "PROD_004": "Home & Kitchen - Blender",
        "PROD_005": "Sports - Running Shoes"
    }
    stores = [f"STORE_{chr(64+i)}" for i in range(1, n_stores+1)]
    categories = {
        "PROD_001": "Electronics", "PROD_002": "Electronics",
        "PROD_003": "Apparel", "PROD_004": "Home & Kitchen",
        "PROD_005": "Sports"
    }
    
    records = []
    for product in products:
        for store in stores:
            base_demand = np.random.uniform(50, 200)
            trend = np.random.uniform(0.01, 0.05)
            for i, date in enumerate(dates):
                # Trend component
                trend_val = base_demand + trend * i
                # Weekly seasonality (weekends higher)
                weekly = 1.3 if date.weekday() >= 5 else 1.0
                # Annual seasonality (Q4 peak, summer dip)
                day_of_year = date.timetuple().tm_yday
                annual = 1.0 + 0.3 * np.sin(2 * np.pi * (day_of_year - 80) / 365)
                # Holiday spikes (Black Friday, Christmas)
                is_holiday = 1.0
                if date.month == 11 and date.day >= 25:
                    is_holiday = 2.2
                elif date.month == 12 and date.day >= 20:
                    is_holiday = 1.8
                elif date.month == 1 and date.day <= 7:
                    is_holiday = 0.7  # post-holiday dip
                
                noise = np.random.normal(1.0, 0.1)
                sales = max(0, int(trend_val * weekly * annual * is_holiday * noise))
                price = round(np.random.uniform(50, 500) * (1 + np.random.uniform(-0.05, 0.05)), 2)
                
                records.append({
                    "date": date.strftime("%Y-%m-%d"),
                    "product_id": product,
                    "product_name": product_names[product],
                    "category": categories[product],
                    "store_id": store,
                    "units_sold": sales,
                    "unit_price": price,
                    "revenue": round(sales * price, 2),
                    "day_of_week": date.strftime("%A"),
                    "month": date.month,
                    "quarter": (date.month - 1) // 3 + 1,
                    "year": date.year,
                    "is_weekend": int(date.weekday() >= 5)
                })
    
    df = pd.DataFrame(records)
    return df


def generate_inventory_data(sales_df):
    """Generate inventory levels based on sales patterns."""
    inventory = []
    for (product, store), group in sales_df.groupby(["product_id", "store_id"]):
        avg_daily_sales = group["units_sold"].mean()
        safety_stock = int(avg_daily_sales * 7)
        reorder_point = int(avg_daily_sales * 14)
        max_stock = int(avg_daily_sales * 45)
        
        inventory.append({
            "product_id": product,
            "store_id": store,
            "current_stock": int(avg_daily_sales * np.random.uniform(10, 30)),
            "safety_stock": safety_stock,
            "reorder_point": reorder_point,
            "max_stock": max_stock,
            "avg_daily_sales": round(avg_daily_sales, 2),
            "lead_time_days": int(np.random.uniform(3, 14))
        })
    
    return pd.DataFrame(inventory)


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    print("Generating synthetic sales data...")
    sales_df = generate_sales_data()
    sales_df.to_csv("data/sales_raw.csv", index=False)
    print(f"  → sales_raw.csv: {len(sales_df):,} rows")
    
    inventory_df = generate_inventory_data(sales_df)
    inventory_df.to_csv("data/inventory.csv", index=False)
    print(f"  → inventory.csv: {len(inventory_df)} rows")
    
    print("Data generation complete.")
