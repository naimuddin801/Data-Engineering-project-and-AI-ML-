"""
Mall Customers Analysis with PySpark
=====================================
Performs EDA, segmentation, clustering insights, and generates report data.
"""

import os
import json
import math
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType
from pyspark.sql.window import Window
from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.clustering import KMeans
from pyspark.ml.evaluation import ClusteringEvaluator


def create_spark_session():
    return (
        SparkSession.builder
        .appName("MallCustomersAnalysis")
        .master("local[*]")
        .config("spark.sql.shuffle.partitions", "4")
        .config("spark.driver.memory", "2g")
        .getOrCreate()
    )


def load_data(spark, path):
    df = (
        spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .csv(path)
    )
    # Rename for convenience
    df = df.withColumnRenamed("AnnualIncome", "AnnualIncome_k") \
           .withColumnRenamed("SpendingScore", "SpendingScore_1_100")
    return df


def basic_eda(df):
    print("\n" + "="*60)
    print("  BASIC EXPLORATORY DATA ANALYSIS")
    print("="*60)

    print(f"\nTotal Customers : {df.count()}")
    print(f"Columns         : {df.columns}")

    print("\n--- Schema ---")
    df.printSchema()

    print("\n--- Sample Rows ---")
    df.show(5, truncate=False)

    print("\n--- Summary Statistics ---")
    df.describe(["Age", "AnnualIncome_k", "SpendingScore_1_100"]).show()

    # Gender distribution
    print("\n--- Gender Distribution ---")
    df.groupBy("Gender").count().orderBy("count", ascending=False).show()

    return df


def age_segments(df):
    print("\n--- Age Segments ---")
    df = df.withColumn(
        "AgeGroup",
        F.when(F.col("Age") < 25, "Youth (<25)")
         .when(F.col("Age") < 35, "Young Adult (25-34)")
         .when(F.col("Age") < 50, "Middle Age (35-49)")
         .otherwise("Senior (50+)")
    )
    df.groupBy("AgeGroup").agg(
        F.count("*").alias("Count"),
        F.round(F.avg("SpendingScore_1_100"), 2).alias("AvgSpending"),
        F.round(F.avg("AnnualIncome_k"), 2).alias("AvgIncome_k")
    ).orderBy("AgeGroup").show()
    return df


def income_spending_correlation(df):
    print("\n--- Income vs Spending Correlation ---")
    corr = df.stat.corr("AnnualIncome_k", "SpendingScore_1_100")
    print(f"Pearson Correlation (Income vs Spending): {corr:.4f}")
    return corr


def kmeans_clustering(df, k=5):
    print(f"\n--- KMeans Clustering (k={k}) ---")
    feature_cols = ["AnnualIncome_k", "SpendingScore_1_100"]
    assembler = VectorAssembler(inputCols=feature_cols, outputCol="features_raw")
    df_vec = assembler.transform(df)

    scaler = StandardScaler(inputCol="features_raw", outputCol="features",
                            withMean=True, withStd=True)
    scaler_model = scaler.fit(df_vec)
    df_scaled = scaler_model.transform(df_vec)

    kmeans = KMeans(k=k, seed=42, featuresCol="features", predictionCol="cluster")
    model = kmeans.fit(df_scaled)
    df_clustered = model.transform(df_scaled)

    evaluator = ClusteringEvaluator(featuresCol="features", predictionCol="cluster")
    silhouette = evaluator.evaluate(df_clustered)
    print(f"Silhouette Score: {silhouette:.4f}")

    print("\nCluster Profile:")
    df_clustered.groupBy("cluster").agg(
        F.count("*").alias("Size"),
        F.round(F.avg("AnnualIncome_k"), 1).alias("AvgIncome_k"),
        F.round(F.avg("SpendingScore_1_100"), 1).alias("AvgSpending"),
        F.round(F.avg("Age"), 1).alias("AvgAge"),
    ).orderBy("cluster").show()

    return df_clustered, silhouette, model


def spending_deciles(df):
    print("\n--- Spending Score Deciles ---")
    quantiles = df.approxQuantile("SpendingScore_1_100",
                                  [0.1, 0.25, 0.5, 0.75, 0.9], 0.01)
    labels = ["10th", "25th", "50th (Median)", "75th", "90th"]
    for label, q in zip(labels, quantiles):
        print(f"  {label} percentile: {q}")
    return quantiles


def top_spenders(df, n=10):
    print(f"\n--- Top {n} Spenders ---")
    df.orderBy(F.col("SpendingScore_1_100").desc()).show(n, truncate=False)


def gender_analysis(df):
    print("\n--- Gender vs Income & Spending ---")
    df.groupBy("Gender").agg(
        F.count("*").alias("Count"),
        F.round(F.avg("Age"), 1).alias("AvgAge"),
        F.round(F.avg("AnnualIncome_k"), 1).alias("AvgIncome_k"),
        F.round(F.avg("SpendingScore_1_100"), 1).alias("AvgSpending"),
        F.round(F.stddev("SpendingScore_1_100"), 2).alias("StdDevSpending"),
    ).show()


def collect_report_data(df, df_clustered, silhouette, corr, quantiles):
    """Collect all stats into a dict for JSON report output."""
    total = df.count()

    # Basic stats
    stats = df.select(
        F.round(F.avg("Age"), 2).alias("avg_age"),
        F.round(F.avg("AnnualIncome_k"), 2).alias("avg_income"),
        F.round(F.avg("SpendingScore_1_100"), 2).alias("avg_spending"),
        F.round(F.min("Age"), 0).alias("min_age"),
        F.round(F.max("Age"), 0).alias("max_age"),
        F.round(F.min("AnnualIncome_k"), 0).alias("min_income"),
        F.round(F.max("AnnualIncome_k"), 0).alias("max_income"),
        F.round(F.min("SpendingScore_1_100"), 0).alias("min_spending"),
        F.round(F.max("SpendingScore_1_100"), 0).alias("max_spending"),
    ).collect()[0].asDict()

    # Gender split
    gender = {r["Gender"]: r["count"] for r in
              df.groupBy("Gender").count().collect()}

    # Age group breakdown
    df_age = df.withColumn(
        "AgeGroup",
        F.when(F.col("Age") < 25, "Youth")
         .when(F.col("Age") < 35, "Young Adult")
         .when(F.col("Age") < 50, "Middle Age")
         .otherwise("Senior")
    )
    age_groups = [
        r.asDict() for r in
        df_age.groupBy("AgeGroup").agg(
            F.count("*").alias("count"),
            F.round(F.avg("SpendingScore_1_100"), 1).alias("avg_spending"),
            F.round(F.avg("AnnualIncome_k"), 1).alias("avg_income"),
        ).orderBy("AgeGroup").collect()
    ]

    # Cluster profiles
    clusters = [
        r.asDict() for r in
        df_clustered.groupBy("cluster").agg(
            F.count("*").alias("size"),
            F.round(F.avg("AnnualIncome_k"), 1).alias("avg_income"),
            F.round(F.avg("SpendingScore_1_100"), 1).alias("avg_spending"),
            F.round(F.avg("Age"), 1).alias("avg_age"),
        ).orderBy("cluster").collect()
    ]

    # Gender detailed
    gender_detail = [
        r.asDict() for r in
        df.groupBy("Gender").agg(
            F.count("*").alias("count"),
            F.round(F.avg("Age"), 1).alias("avg_age"),
            F.round(F.avg("AnnualIncome_k"), 1).alias("avg_income"),
            F.round(F.avg("SpendingScore_1_100"), 1).alias("avg_spending"),
        ).collect()
    ]

    return {
        "total_customers": total,
        "stats": {k: float(v) if v is not None else None for k, v in stats.items()},
        "gender_distribution": gender,
        "gender_detail": gender_detail,
        "age_groups": age_groups,
        "clusters": clusters,
        "silhouette_score": round(silhouette, 4),
        "income_spending_correlation": round(corr, 4),
        "spending_quantiles": {
            "p10": quantiles[0], "p25": quantiles[1],
            "p50": quantiles[2], "p75": quantiles[3], "p90": quantiles[4]
        }
    }


def main():
    DATA_PATH = os.environ.get("DATA_PATH", "/app/data/mall_customers.csv")
    OUTPUT_DIR = os.environ.get("OUTPUT_DIR", "/app/reports")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    spark = create_spark_session()
    spark.sparkContext.setLogLevel("WARN")

    print("\n🛍️  MALL CUSTOMERS ANALYSIS — PySpark")

    df = load_data(spark, DATA_PATH)
    df = basic_eda(df)
    df = age_segments(df)
    corr = income_spending_correlation(df)
    spending_deciles(df)
    gender_analysis(df)
    top_spenders(df, 10)
    df_clustered, silhouette, model = kmeans_clustering(df, k=5)

    quantiles = df.approxQuantile("SpendingScore_1_100",
                                  [0.1, 0.25, 0.5, 0.75, 0.9], 0.01)
    report_data = collect_report_data(df, df_clustered, silhouette, corr, quantiles)

    json_path = os.path.join(OUTPUT_DIR, "analysis_results.json")
    with open(json_path, "w") as f:
        json.dump(report_data, f, indent=2)
    print(f"\n✅ Analysis results saved: {json_path}")

    spark.stop()
    print("\n✅ Spark session stopped. Analysis complete.")


if __name__ == "__main__":
    main()
