# 🛍️ Mall Customers Analysis — PySpark + Docker

End-to-end customer segmentation pipeline using **Apache PySpark** inside **Docker**.

---

## Project Structure

```
mall-customers/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── README.md
├── data/
│   └── mall_customers.csv       # 200-row dataset
├── reports/                     # ← generated output lands here
│   ├── analysis_results.json
│   └── mall_customers_report.html
└── scripts/
    ├── analysis.py              # PySpark EDA + KMeans clustering
    └── generate_report.py       # HTML report generator
```

---

## Quick Start

### Option A — Docker Compose (recommended)

```bash
# Build and run
docker compose up --build

# Reports appear in ./reports/
open reports/mall_customers_report.html
```

### Option B — Docker CLI

```bash
# Build image
docker build -t mall-analysis .

# Run, mounting reports folder
docker run --rm -v "$(pwd)/reports:/app/reports" mall-analysis
```

### Option C — Local Python (no Docker)

```bash
pip install pyspark==3.5.1
DATA_PATH=data/mall_customers.csv OUTPUT_DIR=reports python scripts/analysis.py
OUTPUT_DIR=reports python scripts/generate_report.py
open reports/mall_customers_report.html
```

---

## What the Pipeline Does

| Step | Script | Description |
|------|--------|-------------|
| 1 | `analysis.py` | Load CSV → EDA → Age groups → Correlation → KMeans (k=5) → save JSON |
| 2 | `generate_report.py` | Read JSON → render polished HTML report |

### Analysis Highlights

- **EDA**: schema, sample rows, summary stats, gender distribution
- **Age Segmentation**: Youth / Young Adult / Middle Age / Senior
- **KMeans Clustering** (k=5, StandardScaler): 5 customer segments with Silhouette score
- **Correlation**: Pearson correlation between annual income and spending score
- **Spending Quantiles**: P10 → P90 breakdown
- **Top Spenders**: Top-10 customer list
- **HTML Report**: interactive visual report with KPI cards, bar charts, segment cards, and insights

---

## Outputs

| File | Description |
|------|-------------|
| `reports/analysis_results.json` | Raw analysis data (KPIs, clusters, quantiles…) |
| `reports/mall_customers_report.html` | Polished visual report — open in any browser |

---

## Configuration

| Env Var | Default | Description |
|---------|---------|-------------|
| `DATA_PATH` | `/app/data/mall_customers.csv` | Path to input CSV |
| `OUTPUT_DIR` | `/app/reports` | Output directory |

---

## Dataset

`mall_customers.csv` — 200 rows, 5 columns:

| Column | Type | Description |
|--------|------|-------------|
| CustomerID | int | Unique ID |
| Gender | string | Male / Female |
| Age | int | Customer age |
| AnnualIncome | int | Annual income in thousands ($) |
| SpendingScore | int | Mall-assigned score 1–100 |

---

## Tech Stack

- **Apache PySpark 3.5** — distributed data processing and MLlib clustering
- **Python 3.11** — report generation
- **Docker / Compose** — containerised, reproducible environment
- **OpenJDK** — JVM backend for Spark
