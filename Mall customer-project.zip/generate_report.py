"""
Mall Customers — HTML Report Generator
Reads analysis_results.json and produces a polished HTML report.
"""

import json
import os
from datetime import datetime


CLUSTER_LABELS = {
    0: ("Careful Spenders", "#6c63ff", "Low income, moderate spending"),
    1: ("High Earners", "#00b894", "High income, high spending — prime targets"),
    2: ("Budget Conscious", "#fdcb6e", "Low income, low spending"),
    3: ("Affluent Savers", "#e17055", "High income, low spending"),
    4: ("Young Enthusiasts", "#0984e3", "Moderate income, very high spending"),
}

def cluster_name(idx, data):
    """Heuristically assign human label based on income/spending."""
    inc = data["avg_income"]
    spe = data["avg_spending"]
    if inc >= 70 and spe >= 65:
        return ("Premium Shoppers", "#00b894")
    elif inc >= 70 and spe < 40:
        return ("Affluent Savers", "#e17055")
    elif inc < 50 and spe >= 60:
        return ("Enthusiastic Budget", "#6c63ff")
    elif inc < 50 and spe < 40:
        return ("Cautious Spenders", "#fdcb6e")
    else:
        return ("Standard Visitors", "#0984e3")


def bar(value, max_val=100, color="#6c63ff"):
    pct = min(100, round(value / max_val * 100, 1))
    return f'<div style="background:#f0f0f0;border-radius:6px;height:14px;width:100%"><div style="background:{color};width:{pct}%;height:14px;border-radius:6px;transition:width 0.4s"></div></div>'


def generate_html(data):
    s = data["stats"]
    g = data["gender_distribution"]
    clusters = data["clusters"]
    age_groups = data["age_groups"]
    q = data["spending_quantiles"]
    corr = data["income_spending_correlation"]
    sil = data["silhouette_score"]
    total = data["total_customers"]
    male_pct = round(g.get("Male", 0) / total * 100, 1)
    female_pct = round(g.get("Female", 0) / total * 100, 1)
    now = datetime.now().strftime("%B %d, %Y — %H:%M")

    # Build cluster cards
    cluster_cards = ""
    for c in sorted(clusters, key=lambda x: x["cluster"]):
        label, color = cluster_name(c["cluster"], c)
        pct = round(c["size"] / total * 100, 1)
        cluster_cards += f"""
        <div class="cluster-card">
            <div class="cluster-badge" style="background:{color}">{label}</div>
            <div class="cluster-stats">
                <div class="c-stat"><span class="c-label">Customers</span><span class="c-val">{c['size']} <small>({pct}%)</small></span></div>
                <div class="c-stat"><span class="c-label">Avg Age</span><span class="c-val">{c['avg_age']}</span></div>
                <div class="c-stat"><span class="c-label">Income (k$)</span><span class="c-val">{c['avg_income']}</span></div>
                <div class="c-stat"><span class="c-label">Spending</span><span class="c-val">{c['avg_spending']}</span></div>
            </div>
            <div style="margin-top:8px">{bar(c['avg_spending'], 100, color)}</div>
        </div>"""

    # Build age group rows
    age_rows = ""
    age_colors = {"Youth": "#6c63ff", "Young Adult": "#0984e3", "Middle Age": "#00b894", "Senior": "#e17055"}
    for ag in age_groups:
        grp = ag["AgeGroup"]
        color = age_colors.get(grp, "#888")
        age_rows += f"""
        <tr>
            <td><span class="badge" style="background:{color}">{grp}</span></td>
            <td class="num">{ag['count']}</td>
            <td class="num">{round(ag['count']/total*100,1)}%</td>
            <td>{bar(ag['avg_income'], 120, color)}<small>{ag['avg_income']}k</small></td>
            <td>{bar(ag['avg_spending'], 100, color)}<small>{ag['avg_spending']}</small></td>
        </tr>"""

    # Gender detail rows
    gd_rows = ""
    gd_colors = {"Male": "#0984e3", "Female": "#e84393"}
    for gd in sorted(data["gender_detail"], key=lambda x: x["Gender"]):
        color = gd_colors.get(gd["Gender"], "#888")
        gd_rows += f"""
        <tr>
            <td><span class="badge" style="background:{color}">{gd['Gender']}</span></td>
            <td class="num">{gd['count']}</td>
            <td>{bar(gd['avg_age'], 80, color)}<small>{gd['avg_age']} yrs</small></td>
            <td>{bar(gd['avg_income'], 120, color)}<small>{gd['avg_income']}k</small></td>
            <td>{bar(gd['avg_spending'], 100, color)}<small>{gd['avg_spending']}</small></td>
        </tr>"""

    corr_desc = "weak" if abs(corr) < 0.3 else "moderate" if abs(corr) < 0.6 else "strong"
    corr_dir = "negative" if corr < 0 else "positive"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mall Customers Analysis Report</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #f5f6fa; color: #2d3436; }}

  .header {{
    background: linear-gradient(135deg, #6c63ff 0%, #3f3d56 100%);
    color: white; padding: 48px 40px 36px;
  }}
  .header h1 {{ font-size: 2.2rem; font-weight: 700; letter-spacing: -0.5px; }}
  .header p {{ opacity: 0.8; margin-top: 6px; font-size: 0.95rem; }}
  .header .meta {{ margin-top: 18px; font-size: 0.85rem; opacity: 0.65; }}

  .container {{ max-width: 1100px; margin: 0 auto; padding: 32px 24px; }}
  h2 {{ font-size: 1.25rem; font-weight: 700; color: #2d3436; margin-bottom: 16px;
        border-left: 4px solid #6c63ff; padding-left: 12px; }}

  .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 36px; }}
  .kpi {{
    background: white; border-radius: 12px; padding: 24px 20px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.07); text-align: center;
    border-top: 4px solid var(--accent, #6c63ff);
  }}
  .kpi .val {{ font-size: 2rem; font-weight: 800; color: var(--accent, #6c63ff); line-height: 1; }}
  .kpi .lbl {{ font-size: 0.78rem; color: #888; margin-top: 6px; text-transform: uppercase; letter-spacing: 0.05em; }}

  .section {{ background: white; border-radius: 12px; padding: 28px 24px;
              box-shadow: 0 2px 12px rgba(0,0,0,0.07); margin-bottom: 28px; }}

  .gender-bars {{ display: flex; gap: 24px; }}
  .gender-bar-wrap {{ flex: 1; }}
  .gender-label {{ font-weight: 600; font-size: 0.85rem; margin-bottom: 6px; }}
  .gender-bar {{ height: 28px; border-radius: 8px; display: flex; align-items: center;
                 padding-left: 12px; color: white; font-weight: 700; font-size: 0.95rem; }}

  .cluster-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }}
  .cluster-card {{ background: #f8f9ff; border-radius: 10px; padding: 20px; border: 1px solid #eee; }}
  .cluster-badge {{ color: white; font-size: 0.78rem; font-weight: 700; padding: 4px 10px;
                    border-radius: 20px; display: inline-block; margin-bottom: 12px; }}
  .cluster-stats {{ display: flex; flex-wrap: wrap; gap: 8px; }}
  .c-stat {{ display: flex; flex-direction: column; min-width: 80px; }}
  .c-label {{ font-size: 0.7rem; color: #888; text-transform: uppercase; }}
  .c-val {{ font-size: 0.95rem; font-weight: 700; color: #2d3436; }}

  table {{ width: 100%; border-collapse: collapse; }}
  th {{ text-align: left; padding: 10px 12px; font-size: 0.78rem; text-transform: uppercase;
        color: #888; border-bottom: 2px solid #f0f0f0; }}
  td {{ padding: 12px 12px; border-bottom: 1px solid #f5f5f5; font-size: 0.9rem; vertical-align: middle; }}
  td.num {{ font-weight: 700; }}
  tr:last-child td {{ border-bottom: none; }}
  tr:hover td {{ background: #fafbff; }}

  .badge {{ color: white; font-size: 0.75rem; font-weight: 700; padding: 3px 10px; border-radius: 20px; }}

  .insights {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px; }}
  .insight-card {{ background: linear-gradient(135deg, #f8f9ff, #fff); border-radius: 10px;
                   padding: 20px; border-left: 4px solid #6c63ff; }}
  .insight-card h4 {{ font-size: 0.9rem; font-weight: 700; margin-bottom: 8px; color: #6c63ff; }}
  .insight-card p {{ font-size: 0.85rem; line-height: 1.6; color: #555; }}

  .quantile-bar {{ display: flex; align-items: stretch; gap: 0; border-radius: 8px; overflow: hidden; height: 36px; margin: 16px 0; }}
  .q-seg {{ display: flex; align-items: center; justify-content: center; font-size: 0.7rem; font-weight: 700; color: white; }}

  .metric-row {{ display: flex; gap: 24px; flex-wrap: wrap; }}
  .metric {{ background: #f8f9ff; border-radius: 10px; padding: 16px 20px; flex: 1; min-width: 160px; }}
  .metric .m-val {{ font-size: 1.6rem; font-weight: 800; color: #6c63ff; }}
  .metric .m-lbl {{ font-size: 0.78rem; color: #888; margin-top: 4px; }}
  .metric .m-desc {{ font-size: 0.8rem; color: #555; margin-top: 6px; font-style: italic; }}

  .footer {{ text-align: center; font-size: 0.78rem; color: #bbb; padding: 32px 0 48px; }}
</style>
</head>
<body>

<div class="header">
  <h1>🛍️ Mall Customers Analysis</h1>
  <p>Customer Segmentation & Behavioral Insights — PySpark</p>
  <div class="meta">Generated: {now} &nbsp;|&nbsp; Engine: Apache Spark (PySpark)</div>
</div>

<div class="container">

  <!-- KPI Row -->
  <div class="kpi-grid" style="margin-top:28px">
    <div class="kpi" style="--accent:#6c63ff">
      <div class="val">{total}</div>
      <div class="lbl">Total Customers</div>
    </div>
    <div class="kpi" style="--accent:#0984e3">
      <div class="val">{round(s['avg_age'],1)}</div>
      <div class="lbl">Avg Age (yrs)</div>
    </div>
    <div class="kpi" style="--accent:#00b894">
      <div class="val">${round(s['avg_income'],0):.0f}k</div>
      <div class="lbl">Avg Annual Income</div>
    </div>
    <div class="kpi" style="--accent:#e17055">
      <div class="val">{round(s['avg_spending'],1)}</div>
      <div class="lbl">Avg Spending Score</div>
    </div>
    <div class="kpi" style="--accent:#fdcb6e">
      <div class="val">{female_pct}%</div>
      <div class="lbl">Female Customers</div>
    </div>
    <div class="kpi" style="--accent:#a29bfe">
      <div class="val">5</div>
      <div class="lbl">Customer Segments</div>
    </div>
  </div>

  <!-- Gender -->
  <div class="section">
    <h2>Gender Distribution</h2>
    <div class="gender-bars">
      <div class="gender-bar-wrap">
        <div class="gender-label" style="color:#e84393">Female — {g.get('Female', 0)} customers ({female_pct}%)</div>
        <div class="gender-bar" style="background:#e84393;width:{female_pct}%">{female_pct}%</div>
      </div>
      <div class="gender-bar-wrap">
        <div class="gender-label" style="color:#0984e3">Male — {g.get('Male', 0)} customers ({male_pct}%)</div>
        <div class="gender-bar" style="background:#0984e3;width:{male_pct}%">{male_pct}%</div>
      </div>
    </div>
    <table style="margin-top:24px">
      <thead><tr><th>Gender</th><th>Count</th><th>Avg Age</th><th>Avg Income</th><th>Avg Spending</th></tr></thead>
      <tbody>{gd_rows}</tbody>
    </table>
  </div>

  <!-- Age Groups -->
  <div class="section">
    <h2>Age Group Breakdown</h2>
    <table>
      <thead><tr><th>Segment</th><th>Count</th><th>Share</th><th>Income (k$)</th><th>Spending Score</th></tr></thead>
      <tbody>{age_rows}</tbody>
    </table>
  </div>

  <!-- Spending Quantiles -->
  <div class="section">
    <h2>Spending Score Distribution</h2>
    <div class="quantile-bar">
      <div class="q-seg" style="width:10%;background:#e17055" title="P10={q['p10']}">P10<br>{q['p10']:.0f}</div>
      <div class="q-seg" style="width:15%;background:#fdcb6e" title="P25={q['p25']}">P25<br>{q['p25']:.0f}</div>
      <div class="q-seg" style="width:25%;background:#00b894" title="P50={q['p50']}">Median<br>{q['p50']:.0f}</div>
      <div class="q-seg" style="width:25%;background:#0984e3" title="P75={q['p75']}">P75<br>{q['p75']:.0f}</div>
      <div class="q-seg" style="width:25%;background:#6c63ff" title="P90={q['p90']}">P90<br>{q['p90']:.0f}</div>
    </div>
    <p style="font-size:0.82rem;color:#888">Half of customers score between <strong>{q['p25']:.0f}</strong> and <strong>{q['p75']:.0f}</strong> (IQR = {q['p75']-q['p25']:.0f})</p>
  </div>

  <!-- ML Metrics -->
  <div class="section">
    <h2>ML Model Metrics</h2>
    <div class="metric-row">
      <div class="metric">
        <div class="m-val">{sil:.3f}</div>
        <div class="m-lbl">Silhouette Score</div>
        <div class="m-desc">{"Excellent" if sil>0.6 else "Good" if sil>0.4 else "Fair"} cluster separation</div>
      </div>
      <div class="metric">
        <div class="m-val">{corr:.3f}</div>
        <div class="m-lbl">Income–Spending Correlation</div>
        <div class="m-desc">{corr_desc.capitalize()} {corr_dir} relationship</div>
      </div>
      <div class="metric">
        <div class="m-val">KMeans</div>
        <div class="m-lbl">Algorithm</div>
        <div class="m-desc">k=5, StandardScaler + Euclidean</div>
      </div>
    </div>
  </div>

  <!-- Clusters -->
  <div class="section">
    <h2>Customer Segments (k=5 Clusters)</h2>
    <div class="cluster-grid">{cluster_cards}</div>
  </div>

  <!-- Insights -->
  <div class="section">
    <h2>Key Insights</h2>
    <div class="insights">
      <div class="insight-card">
        <h4>👑 High-Value Targets</h4>
        <p>Customers with high income and high spending scores represent the most profitable segment. They should receive premium loyalty programs and exclusive offers.</p>
      </div>
      <div class="insight-card">
        <h4>💡 Untapped Potential</h4>
        <p>High earners with low spending scores (Affluent Savers) are a prime re-engagement opportunity. Targeted campaigns can convert their income into spending.</p>
      </div>
      <div class="insight-card">
        <h4>👩 Gender Skew</h4>
        <p>Female customers outnumber males at {female_pct}%. Marketing and product assortment decisions should reflect this demographic reality.</p>
      </div>
      <div class="insight-card">
        <h4>📊 Weak Income Correlation</h4>
        <p>Correlation of {corr:.2f} between income and spending is {corr_desc}, suggesting spending behavior is driven by factors beyond income alone — lifestyle, preferences, and marketing exposure.</p>
      </div>
      <div class="insight-card">
        <h4>🧑 Age & Spending</h4>
        <p>Youth and Young Adults tend to have high spending scores relative to income, indicating impulse purchasing and trend-driven behavior — ideal for flash sales and social media campaigns.</p>
      </div>
      <div class="insight-card">
        <h4>⚡ Silhouette Confidence</h4>
        <p>A silhouette score of {sil:.3f} validates that the 5-cluster solution produces meaningful, well-separated groups suitable for business decision-making.</p>
      </div>
    </div>
  </div>

</div>
<div class="footer">Mall Customers Analysis Report &mdash; Powered by Apache PySpark &mdash; {now}</div>
</body>
</html>"""


def main():
    INPUT_DIR = os.environ.get("OUTPUT_DIR", "/app/reports")
    json_path = os.path.join(INPUT_DIR, "analysis_results.json")
    html_path = os.path.join(INPUT_DIR, "mall_customers_report.html")

    with open(json_path) as f:
        data = json.load(f)

    html = generate_html(data)

    with open(html_path, "w") as f:
        f.write(html)

    print(f"✅ HTML Report saved: {html_path}")


if __name__ == "__main__":
    main()
