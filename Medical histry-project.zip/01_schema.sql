-- ============================================================
-- Medical Data History - Database Schema
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- PATIENTS
-- ============================================================
CREATE TABLE patients (
    patient_id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    date_of_birth   DATE NOT NULL,
    gender          VARCHAR(20),
    blood_type      VARCHAR(5),
    phone           VARCHAR(20),
    email           VARCHAR(150),
    address         TEXT,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- DOCTORS
-- ============================================================
CREATE TABLE doctors (
    doctor_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    specialization  VARCHAR(100),
    license_number  VARCHAR(50) UNIQUE NOT NULL,
    phone           VARCHAR(20),
    email           VARCHAR(150),
    created_at      TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- DIAGNOSES
-- ============================================================
CREATE TABLE diagnoses (
    diagnosis_id    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES patients(patient_id) ON DELETE CASCADE,
    doctor_id       UUID NOT NULL REFERENCES doctors(doctor_id),
    icd10_code      VARCHAR(20),
    diagnosis_name  VARCHAR(255) NOT NULL,
    severity        VARCHAR(20) CHECK (severity IN ('mild','moderate','severe','critical')),
    notes           TEXT,
    diagnosed_at    TIMESTAMP DEFAULT NOW(),
    resolved_at     TIMESTAMP
);

-- ============================================================
-- MEDICATIONS
-- ============================================================
CREATE TABLE medications (
    medication_id   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(200) NOT NULL,
    generic_name    VARCHAR(200),
    drug_class      VARCHAR(100),
    unit            VARCHAR(50)
);

-- ============================================================
-- PRESCRIPTIONS
-- ============================================================
CREATE TABLE prescriptions (
    prescription_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES patients(patient_id) ON DELETE CASCADE,
    doctor_id       UUID NOT NULL REFERENCES doctors(doctor_id),
    diagnosis_id    UUID REFERENCES diagnoses(diagnosis_id),
    medication_id   UUID NOT NULL REFERENCES medications(medication_id),
    dosage          VARCHAR(100),
    frequency       VARCHAR(100),
    start_date      DATE NOT NULL,
    end_date        DATE,
    status          VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','completed','cancelled')),
    notes           TEXT,
    prescribed_at   TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- LAB RESULTS
-- ============================================================
CREATE TABLE lab_results (
    result_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES patients(patient_id) ON DELETE CASCADE,
    doctor_id       UUID REFERENCES doctors(doctor_id),
    test_name       VARCHAR(200) NOT NULL,
    test_category   VARCHAR(100),
    value           NUMERIC(12,4),
    unit            VARCHAR(50),
    reference_min   NUMERIC(12,4),
    reference_max   NUMERIC(12,4),
    status          VARCHAR(20) GENERATED ALWAYS AS (
        CASE
            WHEN value IS NULL THEN 'pending'
            WHEN value < reference_min THEN 'low'
            WHEN value > reference_max THEN 'high'
            ELSE 'normal'
        END
    ) STORED,
    tested_at       TIMESTAMP DEFAULT NOW(),
    notes           TEXT
);

-- ============================================================
-- VISITS / APPOINTMENTS
-- ============================================================
CREATE TABLE visits (
    visit_id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES patients(patient_id) ON DELETE CASCADE,
    doctor_id       UUID NOT NULL REFERENCES doctors(doctor_id),
    visit_type      VARCHAR(50) CHECK (visit_type IN ('in-person','telehealth','emergency','follow-up')),
    visit_date      TIMESTAMP NOT NULL,
    chief_complaint TEXT,
    vitals          JSONB,
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MEDICAL HISTORY (PATIENT TIMELINE VIEW)
-- ============================================================
CREATE OR REPLACE VIEW patient_medical_timeline AS
SELECT
    p.patient_id,
    p.first_name || ' ' || p.last_name   AS patient_name,
    p.date_of_birth,
    p.blood_type,
    'visit'                               AS event_type,
    v.visit_date                          AS event_date,
    v.visit_type                          AS sub_type,
    v.chief_complaint                     AS description,
    d.first_name || ' ' || d.last_name   AS doctor_name,
    d.specialization
FROM patients p
JOIN visits v ON v.patient_id = p.patient_id
JOIN doctors d ON d.doctor_id = v.doctor_id

UNION ALL

SELECT
    p.patient_id,
    p.first_name || ' ' || p.last_name,
    p.date_of_birth,
    p.blood_type,
    'diagnosis',
    diag.diagnosed_at,
    diag.severity,
    diag.diagnosis_name || COALESCE(' (' || diag.icd10_code || ')', ''),
    d.first_name || ' ' || d.last_name,
    d.specialization
FROM patients p
JOIN diagnoses diag ON diag.patient_id = p.patient_id
JOIN doctors d ON d.doctor_id = diag.doctor_id

UNION ALL

SELECT
    p.patient_id,
    p.first_name || ' ' || p.last_name,
    p.date_of_birth,
    p.blood_type,
    'prescription',
    pr.prescribed_at,
    pr.status,
    m.name || ' ' || COALESCE(pr.dosage,'') || ' — ' || COALESCE(pr.frequency,''),
    d.first_name || ' ' || d.last_name,
    d.specialization
FROM patients p
JOIN prescriptions pr ON pr.patient_id = p.patient_id
JOIN doctors d ON d.doctor_id = pr.doctor_id
JOIN medications m ON m.medication_id = pr.medication_id

UNION ALL

SELECT
    p.patient_id,
    p.first_name || ' ' || p.last_name,
    p.date_of_birth,
    p.blood_type,
    'lab_result',
    lr.tested_at,
    lr.status,
    lr.test_name || ': ' || COALESCE(lr.value::TEXT,'?') || ' ' || COALESCE(lr.unit,''),
    d.first_name || ' ' || d.last_name,
    d.specialization
FROM patients p
JOIN lab_results lr ON lr.patient_id = p.patient_id
LEFT JOIN doctors d ON d.doctor_id = lr.doctor_id

ORDER BY patient_name, event_date DESC;

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_diagnoses_patient    ON diagnoses(patient_id);
CREATE INDEX idx_prescriptions_patient ON prescriptions(patient_id);
CREATE INDEX idx_lab_results_patient  ON lab_results(patient_id);
CREATE INDEX idx_visits_patient       ON visits(patient_id);
CREATE INDEX idx_visits_date          ON visits(visit_date);
CREATE INDEX idx_lab_results_date     ON lab_results(tested_at);
