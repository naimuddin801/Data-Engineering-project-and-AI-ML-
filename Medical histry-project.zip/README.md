# Medical Data History — SQL + Docker + Report

A fully Dockerized PostgreSQL setup for patient medical history tracking with schema, sample data, and automated reports.

---

## Project Structure

```
medical-data-history/
├── Dockerfile                  # Custom PostgreSQL image
├── docker-compose.yml          # Full stack: DB + pgAdmin + Report
├── sql/
│   ├── 01_schema.sql           # Tables, views, indexes
│   ├── 02_seed.sql             # Sample patients, doctors, records
│   └── 03_reports.sql          # Useful report queries
├── scripts/
│   └── generate_report.sh      # Auto-generates text reports
├── config/
│   └── pgadmin_servers.json    # pgAdmin pre-configured server
└── reports/                    # Output directory (auto-created)
```

---

## Quick Start

### 1. Start the database (and pgAdmin)
```bash
docker compose up -d db pgadmin
```

### 2. Connect via psql
```bash
docker exec -it medical_db psql -U medadmin -d medical_db
```

### 3. Open pgAdmin (Web UI)
```
http://localhost:5050
Email:    admin@medical.local
Password: AdminPass2024!
```
The Medical DB server is pre-configured — just enter the DB password: `MedSecret2024!`

### 4. Generate a report file
```bash
docker compose --profile report up report
# Report saved to ./reports/medical_report_<timestamp>.txt
```

---

## Database Schema

| Table           | Description                                |
|-----------------|--------------------------------------------|
| `patients`      | Patient demographics                       |
| `doctors`       | Physician registry                         |
| `diagnoses`     | Clinical diagnoses with ICD-10 codes       |
| `medications`   | Medication catalog                         |
| `prescriptions` | Patient prescriptions (active/completed)   |
| `lab_results`   | Lab tests with auto-computed normal/high/low |
| `visits`        | Appointments with vitals (JSONB)           |

### Key View
```sql
-- Full chronological timeline for any patient
SELECT * FROM patient_medical_timeline WHERE patient_name = 'Alice Johnson';
```

---

## Connection Details

| Setting  | Value        |
|----------|--------------|
| Host     | `localhost`  |
| Port     | `5432`       |
| Database | `medical_db` |
| User     | `medadmin`   |
| Password | `MedSecret2024!` |

---

## Useful Commands

```bash
# Rebuild from scratch (re-runs all SQL)
docker compose down -v && docker compose up -d db

# View live DB logs
docker logs -f medical_db

# Run a specific report query
docker exec -it medical_db psql -U medadmin -d medical_db \
  -c "SELECT * FROM patient_medical_timeline WHERE patient_name = 'Bob Smith';"

# Stop everything
docker compose down
```

---

## Security Note
> The credentials in this project are for **local development only**.  
> Use Docker secrets or environment variable injection for production deployments.
